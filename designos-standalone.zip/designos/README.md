# DesignOS — Product Design Workspace

Standalone HTML application for Product Designers. No build step required.

## Option A — Vercel (static, easiest)

1. Push this repo to GitHub
2. Go to vercel.com → New Project → Import your repo
3. Set:
   - Framework: **Other**
   - Root directory: `public`
   - Build command: *(leave empty)*
   - Output directory: `.` (dot)
4. Deploy — done.

Your app will be live at `https://designos-yourname.vercel.app`

## Option B — Next.js on Vercel

1. Use the `designos-nextjs/` folder
2. Copy `public/index.html` content into a Next.js page component
3. Push to GitHub, connect to Vercel with framework = Next.js

## Option C — Run locally

```bash
# No install needed — just open in browser:
open public/index.html

# Or serve with any static server:
npx serve public
```

## Data persistence

Currently uses `localStorage` — data saved in your browser only.

**To add a real backend**, replace the `loadState()` / `saveState()` functions in index.html with API calls to:
- Supabase (free, recommended)
- PlanetScale
- Vercel KV

## Customization

All styles live in the `<style>` block at the top of `index.html`.
All data and logic live in the `<script>` block at the bottom.

Color accent: change `--acc: #5B4CF5` to any hex.
